package com.example.apfast.model;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Objects;
import java.util.Set;

@Data
@Entity
@Table(name = "members")
public class Member {
    @Id
    @Column(name = "user_id", length = 32)
    private String userId;

    @Column(name = "password", length = 68, nullable = false)
    private String password;

    @Column(name = "is_active")
    private boolean active;

    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id")
    private Set<Role> roles;
}
