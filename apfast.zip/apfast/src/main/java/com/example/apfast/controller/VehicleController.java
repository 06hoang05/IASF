package com.example.apfast.controller;

import com.example.apfast.model.Vehicle;
import com.example.apfast.service.VehicleService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class VehicleController {

    @Autowired
    private VehicleService vehicleService;

    @GetMapping("/monitor")
    public String showMonitorPage(Model model) {
        List<Vehicle> vehicles = vehicleService.getAllVehicles();
        model.addAttribute("vehicles", vehicles);
        return "vehicle-form";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/vehicle/add")
    public String showAddForm(Model model) {
        model.addAttribute("vehicle", new Vehicle());
        return "vehicle-form";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/vehicle/edit/{id}")
    public String showEditForm(@PathVariable Integer id, Model model) {
        Vehicle vehicle = vehicleService.getVehicleById(id);
        model.addAttribute("vehicle", vehicle);
        return "vehicle-form";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/vehicle/save")
    public String saveVehicle(@ModelAttribute Vehicle vehicle) {
        vehicleService.saveVehicle(vehicle);
        return "redirect:/monitor";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/vehicle/delete/{id}")
    public String deleteVehicle(@PathVariable Integer id) {
        vehicleService.deleteVehicle(id);
        return "redirect:/monitor";
    }
}