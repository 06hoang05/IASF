package com.example.apfast.model;

import jakarta.persistence.*;
import lombok.Data;


@Data
@Entity
@Table(name = "vehicle")
public class Vehicle {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "vehicle_id")
    private Integer id;

    @Basic
    @Column(name = "vehicle_name", length = 64, nullable = false)
    private String name;

    @Basic
    @Column(name = "vehicle_model", length = 10, nullable = false)
    private String model;

    @Basic
    @Column(name = "year_of_manufacture", nullable = false)
    private Integer yearOfManufacture;

    @Column(name = "vehicle_color", length = 16)
    private String color;
}
