package com.example.apfast;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApfastApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApfastApplication.class, args);
    }

}
