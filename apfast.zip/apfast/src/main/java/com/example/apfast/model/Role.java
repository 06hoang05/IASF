package com.example.apfast.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "roles")
public class Role {
    @Id
    @Column(name = "user_id")
    private String userId;

    @Column(name = "role")
    private String role;
}