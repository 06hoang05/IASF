package com.example.apfast.repository;

import com.example.apfast.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;


public interface RoleRepository extends JpaRepository<Role,String> {
    String findRolesByUserId(String userId);
}
